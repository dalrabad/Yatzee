import React from 'react';

const ScoreCard = () => <div>ScoreCard</div>

export default ScoreCard;
